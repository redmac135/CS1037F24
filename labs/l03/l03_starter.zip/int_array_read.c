/**
 * -------------------------------------
 * @file  int_array_read.c
 * Lab 3 Source Code File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2024-09-25
 *
 * -------------------------------------
 */
#include "functions.h"

void int_array_read(int *array, int size) {

    // your code here

}
