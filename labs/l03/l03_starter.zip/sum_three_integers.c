/**
 * -------------------------------------
 * @file  functions.c
 * Lab 2 Functions Source Code File
 * -------------------------------------
 * @author name, id, email
 *
 * @version 2024-09-09
 *
 * -------------------------------------
 */
#include "functions.h"

int sum_three_integers(void) {

    // your code here

}
