
#include "functions.h"

// TODO: Implement the function to print all parameters passed on the command line.
void parameters(int argc, char *const argv[]) {
    // Example of how you might start the function
    // printf("Program Parameters:\n\n");

    // Add your code here to handle and print the parameters.
}
