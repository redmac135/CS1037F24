
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <stdio.h>
#include <stdlib.h>

// Prototypes.
void parameters(int argc, char *const argv[]);

#endif /* FUNCTIONS_H_ */
