/**
 * -------------------------------------
 * @file  name_set_initialize.c
 * Lab 5 Source Code File
 * -------------------------------------
 * @author  
 *
 * @version 2024-09-09
 *
 * -------------------------------------
 */
#include "name_set.h"

name_set* name_set_initialize() {
    // Allocate memory to the data structure
    name_set *set = malloc(sizeof *set);
    // Initialize the header fields.
    set->front = NULL;
    set->rear = NULL;
    return set;
}

int name_set_free(name_set **set) {

    // your code here

}

BOOLEAN name_set_append(name_set *set, const char *first_name, const char *last_name) {

    // your code here

}

BOOLEAN name_set_contains(const name_set *set, const char *first_name, const char *last_name) {

    // your code here

}

void name_set_print(const name_set *set) {

    // your code here

}
