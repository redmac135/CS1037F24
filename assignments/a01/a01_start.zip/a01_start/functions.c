#include "functions.h"
#include <math.h>

double feet_to_acres(int square_feet) {
    // TODO: Implement this function
    return 0.0;
}

int mow_lawn(double length, double width, double mowing_speed) {
    // TODO: Implement this function
    return 0;
}

int date_convert(int date) {
    // TODO: Implement this function
    return 0;
}

int falling_time(double distance) {
    // TODO: Implement this function
    return 0;
}

double hypotenuse(double side1, double side2) {
    // TODO: Implement this function
    return 0.0;
}

int sum_even(int n) {
    // TODO: Implement this function
    return 0;
}

double sum_partial_harmonic(int n) {
    // TODO: Implement this function
    return 0.0;
}